#include <iostream>
#include <cstring>

// Define the number of partitions (buckets)
#ifndef K
#define K 3
#endif

namespace Backtracking {

// Global variables for recursion state
int *numbers;       // Array to store the input numbers
bool *used;         // Array to mark if a number has been used
int *bucket_id;     // Records which bucket a number belongs to (k = K, K-1, ..., 1)
int target_sum;     // The target sum for every bucket
int n;              // Total count of numbers

// Helper: Manual implementation of swap
void swap_int(int &a, int &b) {
    int temp = a;
    a = b;
    b = temp;
}

// Custom QuickSort implementation to sort numbers in descending order.
// Replaces std::sort with custom recursive logic.
void quick_sort_desc(int *arr, int left, int right) {
    if (left >= right) return;

    int pivot = arr[left];
    int i = left;
    int j = right;

    while (i < j) {
        // Find element smaller than pivot from right (descending order logic)
        while (i < j && arr[j] <= pivot) j--;
        // Find element larger than pivot from left
        while (i < j && arr[i] >= pivot) i++;
        if (i < j) swap_int(arr[i], arr[j]);
    }
    
    // Place pivot in correct position
    swap_int(arr[left], arr[i]);

    quick_sort_desc(arr, left, i - 1);
    quick_sort_desc(arr, i + 1, right);
}

/**
 * Recursive Backtracking Function
 * 
 * @param k Current bucket we are trying to fill (counts down from K to 1)
 * @param current_bucket_sum Current sum of the bucket k
 * @param start_index Index to start searching from to avoid duplicates/permutations
 * @return True if a valid partition is found, False otherwise.
 */
bool backtrack(int k, int current_bucket_sum, int start_index) {
    
    // If it is the last bucket (k==1), no need to recurse.
    // Since the previous (K-1) buckets are filled and the total sum is divisible by K,
    // the remaining numbers must inevitably sum up to the target.
    // We just need to mark all unused numbers as belonging to bucket 1.
    if (k == 1) {
        for (int i = 0; i < n; i++) {
            if (!used[i]) {
                bucket_id[i] = 1; // Assign remaining to the last bucket (logical bucket 1)
            }
        }
        return true;
    }

    // If the current bucket is full, start filling the next bucket (k-1)
    // Reset current_sum to 0 and start_index to 0.
    if (current_bucket_sum == target_sum) {
        return backtrack(k - 1, 0, 0);
    }

    for (int i = start_index; i < n; i++) {
        if (used[i]) continue; // Already used by another bucket

        // Pruning 1: Exceeds target sum
        if (current_bucket_sum + numbers[i] > target_sum) continue;

        // Pruning 2: Handle duplicates to avoid symmetric searches (Symmetry Breaking)
        // If current number is the same as the previous one and the previous one 
        // was not used (skipped), then using this one is redundant.
        if (i > start_index && numbers[i] == numbers[i - 1] && !used[i - 1]) continue;

        // --- Action ---
        used[i] = true;
        bucket_id[i] = k; // Record: this number belongs to logical bucket k

        // --- Recurse ---
        if (backtrack(k, current_bucket_sum + numbers[i], i + 1)) {
            return true;
        }

        // --- Backtrack (Undo selection) ---
        used[i] = false;
        bucket_id[i] = 0; // Clear record

        // Pruning 3: 
        // If we fail to fill the bucket even when picking the first available number 
        // (which is the largest available due to sorting), then no solution exists 
        // for this configuration. This is because this largest number MUST belong 
        // to some bucket, and if it can't fit in the current empty bucket, 
        // it won't fit anywhere else equivalent.
        if (current_bucket_sum == 0) return false;
    }

    return false;
}

/**
 * Main Solver Interface
 * @param input_n The number of elements.
 * @param input_numbers Pointer to the array of numbers.
 * @param k Number of partitions (buckets) to divide into.
 */
void solve(int input_n, int *input_numbers, int k) {
    n = input_n;
    int k_partitions = k;
  
    // Allocate memory
    numbers = new int[n];
    if (n > 0) {
        std::memcpy(numbers, input_numbers, n * sizeof(int));
    }

    used = new bool[n];
    std::memset(used, 0, n * sizeof(bool));

    bucket_id = new int[n];
    std::memset(bucket_id, 0, n * sizeof(int));

    // Calculate total sum
    long long total_sum = 0;
    for (int i = 0; i < n; ++i)
        total_sum += numbers[i];

    // Validation: The total sum must be divisible by k_partitions
    if (total_sum % k_partitions != 0) {
        std::cout << "no" << std::endl;
        delete[] numbers;
        delete[] used;
        delete[] bucket_id;
        return;
    }

    target_sum = (int)(total_sum / K);

    // Optimization: Sort numbers in descending order.
    // Replaced std::sort with custom QuickSort implementation.
    quick_sort_desc(numbers, 0, n - 1);

    // Immediate failure check: If the largest number is greater than the target, impossible.
    if (n > 0 && numbers[0] > target_sum) {
        std::cout << "no" << std::endl;
        delete[] numbers;
        delete[] used;
        delete[] bucket_id;
        return;
    }

    // Start recursion: Try to fill K buckets sequentially.
    // We start from k = K down to 1.
    if (backtrack(k_partitions, 0, 0)) {
        std::cout << "yes" << std::endl;
        
        // --- Printing Result ---
        // Iterate to print buckets.
        // The algorithm fills logical buckets K, K-1, ..., 1.
        // To match btk.cpp output style (Bucket 0, Bucket 1...), we map:
        // Logical bucket K -> Display Bucket 0
        // Logical bucket K-1 -> Display Bucket 1
        for (int k = k_partitions; k >= 1; k--) {
            std::cout << "Bucket " << (k_partitions - k) << ": "; 
            for (int i = 0; i < n; i++) {
                if (bucket_id[i] == k) {
                    std::cout << numbers[i] << " ";
                }
            }
            std::cout << std::endl;
        }

    } else {
        std::cout << "no" << std::endl;
    }

    // Clean up dynamic memory
    delete[] numbers;
    delete[] used;
    delete[] bucket_id;
}
} // namespace Backtracking